module Focus {
	requires java.desktop;
}